# pylint: skip-file
print("""

WELCOME GEEK! 🐍 + 💻 = 🤓

- Change the src/models.py file and generate the UML Diagram by typing \033[94m$ pipenv run diagram\033[0m
- Open the generated giagram by doble clicking the \033[94m diagram.png \033[0m file.
""")